Install:
	-Both examples require LeapMotion Core installed first, and Pullcord requires Interaction Engine and TextMeshPro
	-Copy contents of LeapMotion folder into existing project's LeapMotion
	-Drag example folder to Assets projects folder
	-Use the included prefabs to place into your scene

Turntable:
	-Concise example of a proximity shader that uses SDF hand functions
	-No dependancies to Interaction Engine. Code determines if fingertips inside truncated cone, then takes average finger tip delta every frame to rotate table.
	-Has a gradient generator Unity editor script (Overkill for an example but useful to tweak colors)

Pullcords:
	-Example of a UI element normalizing hand movement to 0-1 value, see Debug.Console
	-Grabbed handle will snap back to either end point on pinch release
	-Example of a springy handle that controls 1-axis of movement
	-requires Interaction Engine (for the sphere handles) and TextMeshPro