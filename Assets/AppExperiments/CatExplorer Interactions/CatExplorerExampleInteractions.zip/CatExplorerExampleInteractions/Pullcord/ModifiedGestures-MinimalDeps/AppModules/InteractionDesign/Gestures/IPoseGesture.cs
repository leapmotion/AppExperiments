﻿namespace Leap.Unity.Gestures {

  public interface IPoseGesture : IGesture {

    Pose pose { get; }

  }

}